#include "cards.h"
#include <stdlib.h>

void output(wchar_t* cartasResultantes){
    for (size_t i = 0; i < wcslen(cartasResultantes); i++){
            if(i == wcslen(cartasResultantes) - 1){
                wprintf(L"%lc", cartasResultantes[i]);    
            }
            else{
                wprintf(L"%lc ", cartasResultantes[i]);
            }
    }
    wprintf(L"\n");
}

void reset(MAO* maoInicial, MAO* minhaJogada, wchar_t* carta, wchar_t* minhaJogadaStr, JOGADA* jogada){
    if(maoInicial != NULL) {
        free(maoInicial->freq);
        free(maoInicial->cartas);
        free(maoInicial->combCompleto);
        free(maoInicial);
    }
    if(minhaJogada != NULL){
        free(minhaJogada->freq);
        free(minhaJogada->cartas);
        free(minhaJogada->combCompleto);
        free(minhaJogada);
    }
    free(carta);
    free(minhaJogadaStr);
    if(jogada != NULL) {
        free(jogada->ultimasJogadas);
        free(jogada);
    }
}


MAO* leMao(wchar_t* mao){
    if(fgetws(mao, 1000, stdin)==NULL){return NULL;}
    mao[wcslen(mao)-1] = L'\0';
    if(wcscmp(mao,L"PASSO")==0)return NULL;
    MAO* maoStruct = criaMao(mao);
    // MAO* maoStruct = calloc(1,sizeof(MAO));
    // maoStruct->cartas = calloc((wcslen(mao) + 1), sizeof(wchar_t)); 
    // wcscpy(maoStruct->cartas, mao);
    // maoStruct->freq=calloc(14,sizeof(int));
    // maoStruct->quantidadeCartas = wcslen(mao);
    // maoStruct->combCompleto = veCombinacao(maoStruct);
    
    return maoStruct;
}

int descartaJogadas(int nJogadas){
    wchar_t* temp= calloc(1000, sizeof(wchar_t));
    int i=0;
    for(; i<=nJogadas-4; i++){
        wscanf(L"%ls", temp);
        getwchar();
    }
    free(temp);
    return i;
}

wchar_t** initUltimasMaos(){
    wchar_t** maos = calloc(3*1000,sizeof(wchar_t));
    for (int l = 0; l < 3; l++) {
            maos[l] = calloc(1000, sizeof(wchar_t));
        }
    return maos;
}

int main() {
    setlocale(LC_CTYPE,"C.UTF-8");
    int nTestes, nJogadas;
    wchar_t* maoInicial;
    wscanf(L"%d", &nTestes); //lê numero testes
    for(int j=1; j<=nTestes;j++){
        maoInicial = calloc(1000, sizeof(wchar_t)); //arranja espaço para a mao atual
        wchar_t** maos= initUltimasMaos(); //abre espaço para maos que vai ser o array das ultimas maos 
        wscanf(L"%d", &nJogadas); //le o numero de jogadas
        getwchar();//limpa o buffer
        MAO* maoInicialStruct = leMao(maoInicial);//recebe a mão e transforma numa mao(nao vai ser combinação nenhuma)
        int indiceInicial = descartaJogadas(nJogadas);//vai ler
        for(int k=0;indiceInicial<=nJogadas-1;indiceInicial++, k++){
            if(fgetws(maos[k], 1000, stdin)==NULL)break;
            maos[k][wcslen(maos[k])-1]=0;
        }
        wchar_t* minhaJogada;
        minhaJogada = calloc(1000, sizeof(wchar_t));
        MAO* minhaJogadaStruct = leMao(minhaJogada);
        // wprintf(L"%d\n",minhaJogadaStruct->combCompleto->tipo);
        JOGADA* jogada = criaJogada(maoInicialStruct, nJogadas, maos,minhaJogadaStruct);
        wprintf(L"Teste %d\n", j);
        wchar_t* resultado = aplicaJogada(jogada);
        output(resultado);
        reset(maoInicialStruct, minhaJogadaStruct, maoInicial, minhaJogada, jogada);
    }
    return 0;
}

