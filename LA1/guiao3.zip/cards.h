#ifndef __CARDS_H__
#define __CARDS_H__

#include <wchar.h>
#include <locale.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))


//sugestao do professor no Slack
//enum de combinações
typedef enum{NADA = 0, CJNT = 1, SQC = 2 , DSQC = 3}COMBINACAOTIPO;

//enum de naipes
typedef enum{ESPADAS, COPAS, OUROS, PAUS}NAIPE;

//enum de valor da carta
typedef enum{
    AS,
    DOIS,
    TRES,
    QUATRO,
    CINCO,
    SEIS,
    SETE,
    OITO,
    NOVE,
    DEZ,
    VALETE,
    CAVALEIRO,
    RAINHA,
    REI
}VALOR;

//struct com informação da combinação
typedef struct combinacao {
    wchar_t cartaMaisAlta;
    VALOR valorDoMaior;
    NAIPE naipeDoMaior;
    COMBINACAOTIPO tipo; 
    int nTotalCartas;
}COMBINACAO;

//struct com cada mão que terá as cartas que receberá, o freq como antes, a quantidade de cartas e a struct anterior que vai ter informação da combinação
typedef struct mao{
    wchar_t *cartas;
    int *freq;
    int quantidadeCartas;
    COMBINACAO *combCompleto;
}MAO;

typedef struct jogada
{
    MAO* maoInicial;
    int nJogadas;
    wchar_t** ultimasJogadas;
    MAO* minhaJogada;
}JOGADA;


//Guiao 1
void cartasParaFreq(MAO *mao);
void checkConjunto(MAO *mao);
//Guiao 2
bool combIguais(MAO arr[], int nMaos);
void bubbleOrdenaMaos(MAO arr[], int n);
void veCartaMaior(MAO *mao);
//Guiao 3
MAO* criaMao(wchar_t* cartasn);
JOGADA* criaJogada(MAO* maoInicial, int nJogadasn, wchar_t* jogadas[3], MAO* minhaJogada);
wchar_t* aplicaJogada(JOGADA* jogada);
wchar_t* processaReis(MAO *ultimaJogadaMao, JOGADA *jogada);
COMBINACAO* veCombinacao(MAO *mao);
#endif